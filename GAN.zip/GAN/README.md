# Generative-Adversarial-Network-for-an-MNIST-Handwritten-Digits-From-Scratch-in-Keras

To understand the functionality, Watch this video:
https://youtu.be/8jVhwM0mJW0
